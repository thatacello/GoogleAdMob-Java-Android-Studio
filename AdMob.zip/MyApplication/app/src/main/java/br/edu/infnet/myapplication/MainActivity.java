package br.edu.infnet.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.doubleclick.PublisherAdRequest;
import com.google.android.gms.ads.doubleclick.PublisherAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public static final Random RANDOM = new Random();
    private View main;
    private ImageView garrafa;
    private int lastAngle = -1;
    private PublisherAdView mPublisherAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        main = findViewById(R.id.root);
        garrafa = (ImageView) findViewById(R.id.garrafa);

        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rodarGarrafa();
            }
        });

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

                PublisherAdView adView = new PublisherAdView(MainActivity.this);
                adView.setAdSizes(AdSize.BANNER);
                adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");

                mPublisherAdView = findViewById(R.id.publisherAdView);
                PublisherAdRequest adRequest = new PublisherAdRequest.Builder().build();
                mPublisherAdView.loadAd(adRequest);

            }
        });

    }

    private void rodarGarrafa(){
        int angle = RANDOM.nextInt(3600 - 360) + 360;
        float pivotX = garrafa.getWidth() / 2;
        float pivotY = garrafa.getHeight() / 2;

        final Animation animRotate = new RotateAnimation(lastAngle == -1? 0: lastAngle, angle, pivotX, pivotY);
        lastAngle = angle;
        animRotate.setDuration(2500);
        animRotate.setFillAfter(true);

        garrafa.startAnimation(animRotate);
    }


}
